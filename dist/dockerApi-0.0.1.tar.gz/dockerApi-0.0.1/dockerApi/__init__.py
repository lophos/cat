def run(a):
	print(a)

