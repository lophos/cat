from setuptools import setup, find_packages
setup(
    name="dockerApi",
    version="0.0.1",
    description="dockerApi",
    author="Mai",
    include_package_data=True,
    packages=find_packages(),
)


